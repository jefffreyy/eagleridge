<?php defined('BASEPATH') or exit('No direct script access allowed');
ob_start();
class login extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('login/login_model');
    $this->load->model('templates/header_model');
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    $this->load->library('session');
    $this->load->driver('cache');
    $this->no_cache();
  }







  function index()
  {
    $data['DISP_LOGO'] = $this->header_model->get_logo();
    // var_dump($data['DISP_LOGO']);
    $this->session->unset_userdata('SESS_USER_ID');
    $this->session->unset_userdata('SESS_ADMIN');
    $data['forgot_pass_disable_enable']               = $this->login_model->get_system_setup_by_setting2('forgot_pass_disable_enable', '0');
    $data["maiya_theme"]                        = $this->login_model->GET_MAYA_THEME();
    delete_cookie('username');
    delete_cookie('password');
    delete_cookie('cookie_search');
    $this->load->view('login/login_views', $data);
  }

  function maintenance()
  {
    $this->session->unset_userdata('SESS_USER_ID');
    $this->session->unset_userdata('SESS_ADMIN');
    delete_cookie('username');
    delete_cookie('password');
    delete_cookie('cookie_search');

    $this->load->view('login/maintenance_views');
  }

  function session_expired()
  {
    $this->session->unset_userdata('SESS_USER_ID');
    $this->session->unset_userdata('SESS_ADMIN');
    delete_cookie('username');
    delete_cookie('password');
    delete_cookie('cookie_search');

    $this->load->view('login/session_expired_views');
  }

  function forgot_password()
  {
    $data['forgot_pass_disable_enable']               = $this->login_model->get_system_setup_by_setting2('forgot_pass_disable_enable', '0');

    if ($data['forgot_pass_disable_enable'] != 1) {
      redirect('login');
    }
    $data['DISP_LOGO']                                            = $this->login_model->GET_LOGO();
    $this->load->view('login/forgot_pass_views', $data);
  }

  function change_password()
  {
    $this->load->view('login/change_pass_views');
  }

  function ip_address()
  {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
      $ipaddress                                                = $_SERVER['HTTP_CLIENT_IP'];
    else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
      $ipaddress                                                = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_X_FORWARDED']))
      $ipaddress                                                = $_SERVER['HTTP_X_FORWARDED'];
    else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
      $ipaddress                                                = $_SERVER['HTTP_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_FORWARDED']))
      $ipaddress                                                = $_SERVER['HTTP_FORWARDED'];
    else if (isset($_SERVER['REMOTE_ADDR']))
      $ipaddress                                                = $_SERVER['REMOTE_ADDR'];
    else
      $ipaddress                                                = 'UNKNOWN';
    return $ipaddress;
  }

  function sign_in()
  {
    $ip_add                                                       = $this->login_model->GET_IP_ADDRESS($this->ip_address());
    $activate_ip_address                                          = $this->login_model->GET_SYSTEM_IP_ADDRESS();

    $maintenance                                                  = $this->login_model->GET_MAINTENANCE();

    $activation                                                   = $this->login_model->GET_ACTIVATION();
    if ($activation == "0") {
      redirect('client_activation/deactivated');
      return;
    }

    if ($maintenance == '1') {
      $this->load->view('login/maintenance_views');
    } else {

      $empl_id                                                      = htmlentities($this->input->post('CALC_INPF_EMPL_ID'));
      $password                                                     = htmlentities($this->input->post('CALC_INPF_PASS'));
      $remember                                                     = htmlentities($this->input->post('remember'));
      $input_password                                               = $this->input->post('CALC_INPF_PASS');
      if ($empl_id && $password) {
        if (count($this->login_model->VALIDATE_USER($empl_id))) {
          $user = $this->login_model->GET_USER_ID($empl_id);
          $disabled = $this->login_model->GET_DISABLED($empl_id);
          if ($user) {
            $this->session->set_userdata('SESS_USER_ID', $user->id);
          }
          if ($user->password_attempt >= 10) {
            $this->system_functions->log_access('Unable to login-Account Locked', 'login action');
            $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E103] Account Locked');
            redirect('login');
          }

          if ($disabled > 0) {
            $this->system_functions->log_access('Unable to login-Disabled Account', 'login action');
            $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E102] Account Disabled');
            redirect('login');
            return;
          }

          $user_access_id     = $this->login_model->GET_USER_ACCESS_ID($user->id);
          //   $user_id                                                = $this->login_model->LOGIN_USER($empl_id, $password, $user->col_salt_key);
          $user_id            = '';
          if (password_verify($input_password . $user->col_salt_key, $user->col_user_pass)) {
            // Password is correct
            $user_id = $user->id;
          } else {
            $this->system_functions->log_access('Unable to login-Wrong password', 'login action');
            $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E101] Incorrect Password');
            redirect('login');
          }
          //   if (!$user_id) {
          //     $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E101] Incorrect Password');
          //     $this->login_model->UPDATE_ATTEMPT($user->id, TRUE);
          //     redirect('login');
          //   }
          if ($activate_ip_address == 1) {
            if ($ip_add <= 0) {
              $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E104] IP Address Blocked..');
              $this->system_functions->log_access('Unable to login-IP Block', 'login action');
              redirect('login');
              return;
            }
          }

          $this->login_model->UPDATE_ATTEMPT($user->id, FALSE);
          $check_status         = $this->login_model->GET_USER_STATUS($user_id);
          $this->session->set_userdata('SESS_USER_ACCESS_ID', $user_access_id);
          $this->session->set_userdata('SESS_USER_ID', $user_id);

          if ($remember) {
            set_cookie("username", $empl_id, 2 * 60);
            set_cookie("password", $password, 2 * 60);
          }

          if ($check_status == 0) {
            redirect('login/change_password');
          } else {
            $this->session->set_userdata('SESS_SUCC_MSG_LOGIN', 'Login Successfully!');

            $this->login_model->RECORD_SUCCESSFUL_LOGIN($user->id);
            $this->session->set_userdata('SESS_ADMIN', '0');
            $this->system_functions->log_access('Successfully login', 'login action');
            redirect('home');
          }
        } else {
          $this->session->set_userdata('SESS_ERR_MSG_INVALID1', '[E100] Account does not exist');
          redirect('login');
        }
      }
    }
  }

  function submit_new_password()
  {
    $user_id                                                    = $this->input->post('user_id');
    $new_password                                               = $this->input->post('new_password');
    $retype_password                                            = $this->input->post('retype_password');

    if ($new_password == $retype_password) {

      if (preg_match('/[\^£$%&*()}{#~?><>,|=+¬-]/', $new_password)) {
        $this->session->set_userdata("SESS_ERR_PASSWORD", "Invalid Password only '@','_', and '.' are permitted");
        $this->system_functions->log_access('Unable to change password', 'change password');
        redirect('login/change_password');
      } else {

        $this->login_model->MOD_CHANGE_PASSWORD($new_password, $user_id);
        $this->session->set_userdata('SESS_SUCC_MSG_LOGIN', 'Login Successfully!');
        $this->system_functions->log_access('Successfully change password', 'change password');
        $this->system_functions->log_access('Successfully login', 'login action');
        redirect('home');
      }
    } else {
      $this->session->set_userdata("SESS_ERR_PASSWORD", "Password does not match");
      $this->system_functions->log_access('Unable to change password', 'change password');
      redirect('login/change_password');
    }
  }
  function submit_user_new_password()
  {
    $user_id                                                    = $this->input->post('user_id');
    $new_password                                               = $this->input->post('new_password');
    $retype_password                                            = $this->input->post('retype_password');

    if ($new_password == $retype_password) {

      if (preg_match('/[\^£$%&*()}{#~?><>,|=+¬-]/', $new_password)) {
        $this->session->set_userdata("SESS_ERR_PASSWORD", "Invalid Password only '@','_', and '.' are permitted");
        $this->system_functions->log_access('Unable to change password', 'change password');
        redirect('login/change_password');
      } else {

        $res = $this->login_model->MOD_CHANGE_PASSWORD($new_password, $user_id);
        $this->login_model->DELETE_SESS_PASS($user_id);
        //   $this->session->set_userdata('SESS_SUCC_MSG_LOGIN','Login Successfully!');
        $this->system_functions->log_access('Successfully change password', 'change password');
        $this->system_functions->log_access('Successfully login', 'login action');
        redirect('home');
      }
    } else {
      $this->session->set_userdata("SESS_ERR_PASSWORD", "Password does not match");
      $this->system_functions->log_access('Unable to change password', 'change password');
      redirect('login/change_password');
    }
  }

  function send_email()
  {

    $user_name = $this->input->post('user_name');

    $res = $this->login_model->GET_USER_EMAIL($user_name);
    $salt = bin2hex(openssl_random_pseudo_bytes(22));
    $res->sess = $salt;
    // $user_email='';
    // if($res){
    //     $user_email=$res->col_empl_emai;
    //     $salt=bin2hex(openssl_random_pseudo_bytes(22));
    //     $res['sess']=$salt;
    // }
    echo json_encode($res);
  }

  function new_password()
  {
    $empl_id                                                      = $this->input->get('id');
    $this->session->set_userdata('SESS_USER_ID', $empl_id);
    $this->login_model->MOD_UPDT_REAL_PASS($empl_id);

    $this->load->view('login/new_password_views');
  }
  function user_new_password()
  {
    $empl_id      = $this->input->get('user');
    $sess         = $this->input->get('sess');
    $current_date = date('Y-m-d H:i:s');
    $res          = $this->login_model->GET_SESS_PASS($empl_id, $sess, $current_date);
    if (!$res) {
      redirect('login');
    }
    if (!$sess || !$empl_id) {
      redirect('login');
    }
    $this->session->set_userdata('SESS_USER_ID', $empl_id);

    $this->load->view('login/user_new_password_views');
  }
  function add_session()
  {
    $input_data                 = $this->input->post();
    $input_data['create_date']  = date('Y-m-d H:i:s');
    $input_data['edit_date']    = date('Y-m-d H:i:s');

    $currentDate = new DateTime(); // Get the current date and time
    $currentDate->add(new DateInterval('PT30M')); // Add 30 minutes
    $input_data['expiration'] = $currentDate->format('Y-m-d H:i:s');
    $this->login_model->ADD_SESS_PASS($input_data);
    echo json_encode($input_data);
  }
  function sign_out()
  {
    $this->system_functions->log_access('User Logout', 'logout action');
    // $this->session->sess_destroy(); // Destroy the session first

    if ($this->session->userdata('SESS_ADMIN')) {
      redirect('admin/user_select');
      return;
    }

    if ($this->session->userdata('SESS_SPE_ACCOUNT')) {
      redirect('payrollaccount');
      return;
    }

    $this->session->sess_destroy();
    $this->cache->clean();
    ob_clean();
    redirect('login');
  }

  function no_cache()
  {
    $this->output->set_header('Last-Modified:' . gmdate('D, d M Y H:i:s') . 'GMT');
    $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
    $this->output->set_header('Cache-Control: post-check=0, pre-check=0', false);
    $this->output->set_header('Pragma: no-cache');
  }
}
