<?php $this->load->view('templates/companycontribution_style'); ?>
<?php $this->load->view('templates/css_link'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.css" />


<div class="content-wrapper">
    <div class="container-fluid p-4">
        <div class="flex-fill">

            <div class="row p-0">
                <div class="col-md-6">
                    <h1 class="page-title"><a href="<?= base_url() . 'employees'; ?>"><img style="width: 24px; height: 24px; margin: 0 0 6px 5px" src="<?= base_url('assets_system/icons/circle-left-duotone.svg') ?>" alt=""></a>&nbsp;Employee Settings<h1>
                </div>
                <div class="col-md-6" style="text-align: right;">
                </div>
            </div>
            <hr>

            <div class="ml-0 pr-0 pl-0 " style="display: flex; align-items: center; justify-content: center;">
                <div class="card col-xl-8 col-lg-4 col-md-8 col-8" style="min-height:700px ">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <?php $this->load->view('templates/settings_employee_nav_views'); ?>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-md-12">
                                    <span style="font-weight: 500; font-size: 18px">Number Of Approvers</span>
                                </div>

                                <div class="col-md-12">

                                </div>
                            </div>


                            <hr>
                            <div class="form-group">
                                <label for="approver_count">Number Of Approver</label>
                                <select style="max-width: 60px;" class="form-control" id="approver_count" value="">
                                    <option value="0" <?= $approver_count == 0 ? 'selected' : '' ?>>0</option>
                                    <option value="1" <?= $approver_count == 1 ? 'selected' : '' ?>>1</option>
                                    <option value="2" <?= $approver_count == 2 ? 'selected' : '' ?>>2</option>
                                    <option value="3" <?= $approver_count == 3 ? 'selected' : '' ?>>3</option>
                                    <option value="4" <?= $approver_count == 4 ? 'selected' : '' ?>>4</option>
                                    <option value="5" <?= $approver_count == 5 ? 'selected' : '' ?>>5</option>
                                </select>
                            </div>
                            <div class="d-flex justify-content-center">
                                <button class="btn btn-primary" onclick="update_approver_count()">Save</button>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<aside class="control-sidebar control-sidebar-dark">
</aside>
<?php $this->load->view('templates/jquery_link'); ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.js"></script>



<script>
    function update_approver_count() {
        const approver_count = document.getElementById('approver_count').value;
        var url = '<?= base_url() ?>';


        fetch(url + 'employees/update_approver_count', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(approver_count)
            })
            .then(response => response.json())
            .then(result => {
                console.log(result);
                if (result.success_message) {
                    $(document).Toasts('create', {
                        class: 'bg-success toast_width',
                        title: 'Success!',
                        subtitle: 'close',
                        body: result.success_message
                    })
                }

                if (result.warning_message) {
                    $(document).Toasts('create', {
                        class: 'bg-warning toast_width',
                        title: 'Warning!',
                        subtitle: 'close',
                        body: result.warning_message
                    })
                }

            })
            .catch(error => {
                $(document).Toasts('create', {
                    class: 'bg-warning toast_width',
                    title: 'Warning!',
                    subtitle: 'close',
                    body: 'Please provide all required information.'
                })
                console.error('Data update error:', error);
            });
    }
</script>