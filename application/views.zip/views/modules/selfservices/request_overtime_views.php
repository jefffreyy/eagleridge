<?php $this->load->view('templates/css_link'); ?>

<head>
    <!-- Include Moment.js -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script> -->
    <script src="<?= base_url('assets_system') ?>/_eyeboxroot/plugins/moment/moment.min.js"></script>
    <!-- Include DateRangePicker CSS -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"> -->
    <!-- Include DateRangePicker JavaScript -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> -->
    <style>
        .calendar-table {
            display: none !important;
        }
    </style>
</head>
<div class="content-wrapper" style="min-height: 624px;">
    <div class='row'>
        <div class='col-md-8 ml-4 mt-3'>
            <h2><a href="my_overtimes"><img style="width: 32px; height: 32px;" src="<?= base_url('assets_system/icons/circle-left-duotone.svg') ?>" alt="">
                </a></h2>
        </div>
    </div>

    <div class="container-fluid px-4">

        <div class="row d-flex justify-content-center">
            <div class="col-sm-6">
                <div class="card">
                    <div class="modal-body pb-5">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="<?= base_url('selfservices/add_request_overtime') ?>" method='post'>
                                    <input type='hidden' value="<?= $this->session->userdata('SESS_USER_ID') ?>" name='assigned_by' />
                                    <input type='hidden' value="<?= $this->session->userdata('SESS_USER_ID') ?>" id="input_employee_id" name='empl_id' />

                                    <!-- <div class="form-group">
                                        <label class="">Shift Type</label>
                                        <select class="form-control" name="type" id="type" enabled="">
                                            <option>Regular</option>
                                            <option> Night Shift</option>
                                            <option> Rest</option>
                                            <option> Special</option>
                                            <option> Legal</option>
                                            <option> Rest + Special</option>
                                            <option> Rest + Legal</option>
                                        </select>
                                    </div> -->
                                    <div class="form-group">
                                        <label class="required" for="input_date_ot">Overtime Date</label>
                                        <input type="date" class="form-control" name="date_ot" id="input_date_ot" value="<?= date('Y-m-d') ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="type">Date Type</label>
                                        <input type="text" class="form-control" name="type" id="type" value="" readonly>
                                    </div>
                                    <div class="form-group">

                                        <label class="required">Shift Type</label>

                                        <!--<input type="text" id="shift_type" class="form-control" value="" disabled>-->
                                        <p class="p-0 p-2 m-0 bg-light rounded d-flex justify-content-between" id="shift_type"><span>No shift assign</span></p>

                                    </div>
                                    <div class="form-group">
                                        <label class="required d-block " for="input_time_out">Time Range</label>
                                        <div class="input-group">
                                            <input type="text" name="time_out" class="form-control" id="time-range" placeholder="Select time range">
                                            <div class="input-group-prepend">
                                                <button type="button" class="btn btn-sm btn-primary rounded-right " id="clear-button"><img src="<?= base_url('assets_system/icons/clear_filter.svg') ?>" alt="" />&nbsp;Clear</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="required" for="input_hours">Overtime Hours</label>
                                        <input type="number" class="form-control" name="hours" id="input_hours" value="1" min="0.5" step="0.5" required 
                                        <?php if ($disable_overtime_hours == '1') echo 'readonly'; ?>>
                                    </div>
                                    <div class="form-group">
                                        <label class="" for="input_reason">Reason</label>
                                        <textarea name="reason" class="form-control" id="reason" rows="4" cols="50" enabled=""></textarea>
                                    </div>
                                    <input type='hidden' value='Pending 1' name='status' />

                                    <div class="mr-2" style="float: right !important">
                                        <button id="btn_add" type='submit' class="btn technos-button-blue shadow-none rounded " ;="">
                                            Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('templates/jquery_link'); ?>
<?php
if ($this->session->flashdata('SUCC')) {
?>
    <script>
        Swal.fire('<?php echo $this->session->flashdata('SUCC'); ?>', '', 'success')
    </script>
<?php
}
?>
<?php
if ($this->session->flashdata('ERR')) {
?>
    <script>
        Swal.fire('<?php echo $this->session->flashdata('ERR'); ?>',
            '',
            'error'
        )
    </script>
<?php
}
?>

<script>
    document.getElementById('input_hours').addEventListener('input', function() {
        var inputValue = parseFloat(this.value);
        if (isNaN(inputValue) || inputValue < 0.5 || inputValue > 24) {
            this.setCustomValidity('Invalid input for overtime hours.');
            this.classList.add('is-invalid');
        } else {
            this.setCustomValidity('');
            this.classList.remove('is-invalid');
        }
    });
</script>

<script>
    $(document).ready(function() {
        let date = ''; // Initialize the date variable outside the event handler

        $('#input_date_ot, #input_employee_id').on('change', function() {
            let empl_id = $('#input_employee_id').val();
            date = $('#input_date_ot').val(); // Update the global 'date' variable
            let formatted_date = moment(date);
            console.log(formatted_date.format('MM/DD/YYYY'));

            $.post("<?= base_url('overtimes/get_shift_type') ?>", {
                'empl': empl_id,
                'date': date
            }, function(res) {
                if (res) {
                    let name = res.name ? res.name : '';
                    let start_time = res.time_regular_start ? res.time_regular_start : '';
                    let end_time = res.time_regular_end ? res.time_regular_end : '';
                    let html_data = `<span>${name}</span><span>${start_time} To ${end_time}</span>`;
                    $('#shift_type').html(html_data);
                }
                if (res.length <= 0) {
                    $('#shift_type').html(`<span>No shift assign</span>`);
                }
            }, 'json');
        });

        // get the shift type when  page is loaded
        function fetchShiftType() {
            let empl_id = $('#input_employee_id').val();
            date = $('#input_date_ot').val(); // Update the global 'date' variable
            let formatted_date = moment(date);
            console.log(formatted_date.format('MM/DD/YYYY'));

            $.post("<?= base_url('overtimes/get_shift_type') ?>", {
                'empl': empl_id,
                'date': date
            }, function(res) {
                if (res) {
                    let name = res.name ? res.name : '';
                    let start_time = res.time_regular_start ? res.time_regular_start : '';
                    let end_time = res.time_regular_end ? res.time_regular_end : '';
                    let html_data = `<span>${name}</span><span>${start_time} To ${end_time}</span>`;
                    $('#shift_type').html(html_data);
                }
                if (res.length <= 0) {
                    $('#shift_type').html(`<span>No shift assign</span>`);
                }
            }, 'json');
        }

        // Call the function on page load
        fetchShiftType();

        // Bind the function to the change event of input elements
        $('#input_date_ot, #input_employee_id').on('change', function() {
            fetchShiftType();
        });

        // function fetchStdDepartment() {
        //     let empl_id = $('#input_employee_id').val();
        //     $.post("<?= base_url('overtimes/get_department_min_hour') ?>", {
        //         'empl': empl_id
        //     }, function(result) {

        //         let minHour = result.min_hours;
        //         // Update min and step attributes based on minHour value
        //         $('#input_hours').attr('value', (minHour) ? minHour : "");
        //         $('#input_hours').attr('min', (minHour == 1) ? 1 : 0.5);
        //         $('#input_hours').attr('step', (minHour == 1) ? '' : 0.5);
        //     }, 'json');
        // }

        // fetchStdDepartment();
        // $('#input_employee_id').on('change', function() {
        //     fetchStdDepartment();
        // });


        $('#time-range').daterangepicker({
            timePicker: true,
            timePicker24Hour: true,
            showCalendar: false,
            startDate: moment().startOf('hour'),
            endDate: moment().startOf('hour').add(1, 'hour'),
            locale: {
                format: 'HH:mm:ss'
            }
        });

        function calculateOvertime(start, end) {
            const duration = moment.duration(end.diff(start));
            let overtimeHours = duration.asHours();
            if (overtimeHours < 0) {
                overtimeHours += 24;
            }
            return overtimeHours;
        }
        //time range => overtime hours
        $('#time-range').on('apply.daterangepicker', function(ev, picker) {
            const start = picker.startDate;
            const end = picker.endDate;
            const overtimeHours = calculateOvertime(start, end);
            $('#input_hours').val(overtimeHours);
        });

        $('#clear-button').on('click', function() {
            $('#time-range').data('daterangepicker').setStartDate(moment().startOf('hour'));
            $('#time-range').data('daterangepicker').setEndDate(moment().startOf('hour').add(1, 'hour'));
            $('#input_hours').val('1');
        });
    });
</script>

<script>
    $(document).ready(function() {

        function updateDateType() {
            var selectedDate = $('#input_date_ot').val();


            $.ajax({
                url: '<?= base_url('selfservices/check_holiday') ?>',
                method: 'POST',
                data: {
                    date: selectedDate
                },
                success: function(response) {
                    console.log(response);
                    var dateType = (response.isHoliday) ? response.holidayType : 'Regular Day';
                    $('#type').val(dateType);
                },
                error: function(error) {
                    console.error('Error checking holiday:', error);
                }
            });
        }


        $('#input_date_ot').on('input', updateDateType);


        updateDateType();
    });
</script>