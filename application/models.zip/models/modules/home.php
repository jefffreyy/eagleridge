<?php defined('BASEPATH') or exit('No direct script access allowed');
ob_start();
class home extends CI_Controller
{
  function __construct()
  {
    parent::__construct();

    $this->load->model('home/home_model');

    if ($this->session->userdata('SESS_USER_ID') == '') {
      redirect('login/session_expired');
    }

    $maintenance = $this->login_model->GET_MAINTENANCE();
    $isAdmin = $this->session->userdata('SESS_ADMIN');
    if ($maintenance == '1' && $isAdmin != 1) {
      redirect('login/maintenance');
    }
  }

  function index()
  {
    $user_id = $this->session->userdata('SESS_USER_ID');

    $data["WELCOME_MESSAGE"]                        = $this->home_model->GET_WELCOME_MESSAGE();
    // $data["WELCOME_MESSAGE"]                        = 'testcontroller';
    $data["ANNOUNCEMENT_STATUS"]                    = $this->home_model->GET_HOME_ANNOUNCEMENT();
    $data["CELEB_STATUS"]                           = $this->home_model->GET_HOME_CELEBRATION();
    $data["DATE_STATUS"]                            = $this->home_model->GET_HOME_DATE();
    $data["LEAVE_STATUS"]                           = $this->home_model->GET_HOME_LEAVE();
    $data["WHOS_OUT_STATUS"]                        = $this->home_model->GET_HOME_WHOS_OUT();
    $data["HOLIDAY_STATUS"]                         = $this->home_model->GET_SYSTEM_SETUP('home_holiday');
    $data["START_GUIDE_STATUS"]                     = $this->home_model->GET_HOME_START_GUIDE();
    $data["NEW_MEMBER_STATUS"]                      = $this->home_model->GET_HOME_NEW_MEMBER();

    $data['isholiday']                              = $this->home_model->MOD_DISP_HOLIDAY_BASED_DATE(date('Y-m-d'));
    $data['DISP_USER_INFO']                         = $this->home_model->MOD_DISP_HOME($user_id);
    $data['DISP_ANNOUNCEMENTS_INFO']                = $this->home_model->MOD_DISP_ANNOUNCEMENTS(5);
    $data['DISP_EMPOLYEE_INFO']                     = $this->home_model->MOD_DISP_ALL_EMPLOYEES_BY_DATE();

    $data['DISP_ON_LEAVE']                          = $this->home_model->MOD_DISP_ON_LEAVE();
    $data['desktop_logo']                           = $this->home_model->GET_DESKTOP_LOGO()['value'];
    $data['mobile_logo']                            = $this->home_model->GET_MOBILE_LOGO()['value'];
    $data['DISP_NEW_EMP']                           = $this->home_model->DISP_NEW_EMP_MONTH();
    $data['DISP_HOLIDAYS']                          = $this->home_model->GET_HOLIDAYS();
    $data['C_POSITIONS']                            = $this->home_model->GET_POSITION();

    $leave_app_val = $data['LEAVE_APPROVED_COUNT']  = $this->home_model->LEAVE_APPROVED_COUNT($user_id);
    $leave_rej_val = $data['LEAVE_REJECTED_COUNT']  = $this->home_model->LEAVE_REJECTED_COUNT($user_id);
    $data['LEAVE_REJECTED_COUNT2']                  = $this->home_model->LEAVE_REJECTED_COUNT($user_id);
    $data['LEAVE_PENDING_COUNT']                    = $this->home_model->LEAVE_ALL_COUNT($user_id);

    $data['HOLIDAYWORK_APPROVED_COUNT']             = $this->home_model->HOLIDAYWORK_APPROVED_COUNT($user_id);
    $data['HOLIDAYWORK_REJECTED_COUNT']             = $this->home_model->HOLIDAYWORK_REJECTED_COUNT($user_id);
    $data['HOLIDAYWORK_PENDING_COUNT']              = $this->home_model->HOLIDAYWORK_ALL_COUNT($user_id);

    $ot_app_val = $data['OVERTIME_APPROVED_COUNT']  = $this->home_model->OVERTIME_APPROVED_COUNT($user_id);
    $ot_rej_val = $data['OVERTIME_REJECTED_COUNT']  = $this->home_model->OVERTIME_REJECTED_COUNT($user_id);
    $data['OVERTIME_PENDING_COUNT']                 = $this->home_model->OVERTIME_ALL_COUNT($user_id);

    $time_app_val = $data['TIME_APPROVED_COUNT']    = $this->home_model->TIME_APPROVED_COUNT($user_id);
    $time_rej_val = $data['TIME_REJECTED_COUNT']    = $this->home_model->TIME_REJECTED_COUNT($user_id);
    $data['TIME_PENDING_COUNT']                     = $this->home_model->TIME_ALL_COUNT($user_id);


    $data['HOLIDAYWORK_APPROVALS']                  = $this->home_model->GET_HOLIDAYWORK_APPROVALS($user_id);
    $data['LEAVE_APPROVALS']                        = $this->home_model->GET_LEAVE_FOR_APPROVALS($user_id);
    $data['OVERTIME_APPROVALS']                     = $this->home_model->GET_OVERTIME_APPROVALS($user_id);
    $data['TIME_ADJUSTMENT']                        = $this->home_model->GET_TIME_ADJUSTMENT_APPROVALS($user_id);
    $data['LEAVES']                                 = $this->home_model->GET_LEAVES($user_id);
    $data['HOLIDAYWORKS']                           = $this->home_model->GET_HOLIDAYWORK($user_id);
    $data['OVERTIMES']                              = $this->home_model->GET_OVERTIME($user_id);
    $data['TIME_ADJUSTMENTS']                       = $this->home_model->GET_TIME_ADJUSTMENTS($user_id);

    // Biometrics In/out starts
    $empl_id = $this->session->userdata('SESS_USER_ID');
    $shift_assign = $this->home_model->GET_ATTENDANCE_SHIFT_ASSIGN_ID_TODAY_BY_EMP_ID($empl_id);
    $currentDateTime = date("Y-m-d H:i:s");
    $startTime = date('Y-m-d 00:00:00');
    $endTime = date('Y-m-d 23:59:59');
    $scheduledIn = null;
    $scheduledOut = null;
    $shiftIn = null;
    $shiftOut = null;
    $punchIn = null;
    $punchOut = null;
    $shift_specific = $this->home_model->GET_ATTENDANCE_SHIFT_BY_ID(!empty($shift_assign[1]['shift_id']) ? $shift_assign[1]['shift_id'] : null);


    if ($shift_specific) {
      if (!empty($shift_specific[0]['time_regular_start']) && ($timestamp = strtotime($shift_specific[0]['time_regular_start'])) !== false) {
        $shiftIn = date('g:ia', $timestamp);
      }
      if (!empty($shift_specific[0]['time_regular_end']) && ($timestamp = strtotime($shift_specific[0]['time_regular_end'])) !== false) {
        $shiftOut = date('g:ia', $timestamp);
      }
      if ($shift_specific[0]['code'] == 'DS 7-18') {
        if (strtotime($currentDateTime) >= strtotime($startTime) && strtotime($currentDateTime) <= strtotime($endTime)) {
          $dateToday = date("Y-m-d");
          $recordsToday = $this->home_model->GET_ATTENDANCE_RECORD_TODAY_BY_ID_DATE($empl_id, $dateToday);
          if ($recordsToday) {
            if (!empty($recordsToday['time_in']) && ($timestamp = strtotime($recordsToday['time_in'])) !== false) {
              $punchIn = date('g:ia', $timestamp);
            }
            if (!empty($recordsToday['time_out']) && ($timestamp = strtotime($recordsToday['time_out'])) !== false) {
              $punchOut = date('g:ia', $timestamp);
            }
          }
        }
      }
    }
    $data['BIOMETRICS_SHIFT_IN']                       =  $shiftIn;
    $data['BIOMETRICS_SHIFT_OUT']                      =  $shiftOut;
    $data['BIOMETRICS_PUNCH_IN']                       =  $punchIn;
    $data['BIOMETRICS_PUNCH_OUT']                      =  $punchOut;
    // Biometrics In/out ends

    // Time Keeping Summary Starts
    $date_yesterday                 = date('Y-m-d', strtotime('yesterday'));
    $latest_payroll_period_2        = $this->home_model->GET_LATEST_PAYROLL_PERIOD_2($date_yesterday);

    $period_date_start = $latest_payroll_period_2->date_from;
    $period_date_end = $latest_payroll_period_2->date_to;

    $target_date_start = $latest_payroll_period_2->date_from;
    $target_date_end = $date_yesterday;

    $cutOffPeriod = date('M j', strtotime($period_date_start)) . ' - ' . date('M j, Y', strtotime($period_date_end));
    $dateCoverage = date('M j', strtotime($target_date_start)) . ' - ' . date('M j, Y', strtotime($target_date_end));



    $data['CUT_OFF_PERIOD']                 = $cutOffPeriod;
    $data['DATE_COVERAGE']                  = $dateCoverage;


    // $ZK_ATTENDANCE_RECORDS      = $this->home_model->GET_SPECIFIC_ATTENDANCE_LOG_IN_OUT($user_id, $target_date_start, $target_date_end);
    $ZK_ATTENDANCE_RECORDS      = $this->home_model->GET_ZKTECO_ATTENDANCE($user_id, $target_date_start, $target_date_end);
    $REM_ATTENDANCE_RECORDS      = $this->home_model->GET_SPECIFIC_ATTENDANCE_LOG_IN_OUT($user_id, $target_date_start, $target_date_end);
    $LEAVE_ASSIGNS              = $this->home_model->GET_SPECIFIC_LEAVE_ASSIGN($user_id, $target_date_start, $target_date_end);
    $EMPLOYEES_SHIFTS           = $this->home_model->GET_SPECIFIC_ATTENDANCE_EMPLOYEES_SHIFT($user_id, $target_date_start, $target_date_end);

    $lwop = 0;
    $absences = 0;
    $totalWorkedHours = 0;
    $totalTardinessHours = 0;
    $totalUnderTimeHours = 0;
    $totalPaidHours = 0;
    $totalAbsencesHours = 0;
    $totalLeaveWithoutPay = 0;


    $start_timestamp = strtotime($period_date_start);
    $end_timestamp = strtotime($period_date_end);

    for ($current_timestamp = $start_timestamp; $current_timestamp <= $end_timestamp; $current_timestamp += 86400) {
      $LOG_date = date('Y-m-d', $current_timestamp);

      $LOG_shift_code                    = '';
      $LOG_shift_reg_hrs                    = 0;
      $LOG_shift_in                       = '';
      $LOG_shift_out                      = '';
      $LOG_leave                          = 0;
      $LOG_overtime                       = 0;
      $LOG_zkt_act_in                     = '';
      $LOG_zkt_act_out                    = '';
      $LOG_zkt_act_in_prev                = '';
      $LOG_zkt_act_out_prev               = '';

      $LOG_rem_act_in                     = '';
      $LOG_rem_act_out                    = '';

      $LOG_act_in                         = '';
      $LOG_act_out                        = '';

      $work_hours                         = 0;
      $tardiness                         = 0;
      $undertime                         = 0;
      $reg_hrs = 0;

      foreach ($LEAVE_ASSIGNS as $leaveData) {
        if ($leaveData->leave_date == $LOG_date) {
          $LOG_leave   = $leaveData->duration;
        }
      }

      foreach ($EMPLOYEES_SHIFTS as $shiftData) {
        if ($shiftData->date == $LOG_date) {
          $LOG_shift_code = $shiftData->code;
          $LOG_shift_reg_hrs = $shiftData->time_regular_reg;
          $LOG_shift_in   = $shiftData->time_regular_start;
          $LOG_shift_out  = $shiftData->time_regular_end;
        }
      }

      foreach ($ZK_ATTENDANCE_RECORDS as $ZKT_attendance) {
        $punch_time = new DateTime($ZKT_attendance->punch_time);
        $punch_date = $punch_time->format('Y-m-d');
        $punch_state  = $ZKT_attendance->punch_state;

        if ( $punch_date == $LOG_date) {
          if ($punch_state == '0') {
            $LOG_zkt_act_in = $punch_time->format('H:i:s');

            if ($LOG_zkt_act_in_prev != '') {
              $timestamp1 = strtotime($LOG_zkt_act_in);
              $timestamp2 = strtotime($LOG_zkt_act_in_prev);

              if ($timestamp1 > $timestamp2) {
                $LOG_zkt_act_in = $LOG_zkt_act_in_prev;
              }
            }

            $LOG_zkt_act_in_prev = $LOG_zkt_act_in;
          } else if ($punch_state == '1') {
            $LOG_zkt_act_out = $punch_time->format('H:i:s');

            if ($LOG_zkt_act_in_prev != '') {
              $timestamp1 = strtotime($LOG_zkt_act_out);
              $timestamp2 = strtotime($LOG_zkt_act_out_prev);

              if ($timestamp1 < $timestamp2) {
                $LOG_zkt_act_out = $LOG_zkt_act_out_prev;
              }
            }

            $LOG_zkt_act_out_prev = $LOG_zkt_act_out;
          }
        }
      }


      foreach ($REM_ATTENDANCE_RECORDS as $REM_attendance) {
        if ($REM_attendance->date == $LOG_date) {
          $LOG_rem_act_in                     = $REM_attendance->time_in;
          $LOG_rem_act_out                    = $REM_attendance->time_out;
        }
      }

      if ($LOG_zkt_act_in == '' && $LOG_rem_act_in != '') {
        $LOG_act_in = $LOG_rem_act_in;
      } else if ($LOG_zkt_act_in != '' && $LOG_rem_act_in == '') {
        $LOG_act_in = $LOG_zkt_act_in;
      } else if ($LOG_zkt_act_in != '' && $LOG_rem_act_in != '') {
        $timestamp1 = strtotime($LOG_zkt_act_in);
        $timestamp2 = strtotime($LOG_rem_act_in);

        if ($timestamp1 > $timestamp2) {
          $LOG_act_in = $LOG_rem_act_in;
        } else {
          $LOG_act_in = $LOG_zkt_act_in;
        }
      }

      if ($LOG_zkt_act_out == '' && $LOG_rem_act_out != '') {
        $LOG_act_out = $LOG_rem_act_out;
      } else if ($LOG_zkt_act_out != '' && $LOG_rem_act_out == '') {
        $LOG_act_out = $LOG_zkt_act_out;
      } else if ($LOG_zkt_act_out != '' && $LOG_rem_act_out != '') {
        $timestamp1 = strtotime($LOG_zkt_act_out);
        $timestamp2 = strtotime($LOG_rem_act_out);

        if ($timestamp1 < $timestamp2) {
          $LOG_act_out = $LOG_rem_act_out;
        } else {
          $LOG_act_out = $LOG_zkt_act_out;
        }
      }


      //----------------    CALCULATION START
      if ($LOG_shift_code != '' && $LOG_shift_code != 'REST') {
        $work_hours = $LOG_shift_reg_hrs - $LOG_leave;
      

        if ($LOG_act_in != '' && $LOG_act_out != '') {
          $in_min                 = $this->convert_time_to_float($LOG_act_in, 'minute') - $this->convert_time_to_float($LOG_shift_in, 'minute');

          if ($in_min < 0) {
            $in_min  = 0;
          }
          $tardiness                 =  ceil($in_min / 30);

          $out_min                = $this->convert_time_to_float($LOG_shift_out, 'minute') - $this->convert_time_to_float($LOG_act_out, 'minute');
          if ($out_min < 0) {
            $out_min  = 0;
          }
          $undertime  =  ceil($out_min / 30);

          // $awol       = $absent - $lwop;
          $reg_hrs    = $work_hours - $tardiness - $undertime;

          if ($reg_hrs < 0) {

            $reg_hrs   = 0;
            $tardiness = 0;
            $undertime = 0;
            // $awol       = $work_hours - $lwop;
            // $remarks    = "Invalid IN/OUT, Absent";
          }
        } 
        else {
          $reg_hrs   = 0;
          $tardiness = 0;
          $undertime = 0;
          $awol       = $work_hours;
          // $remarks = "NO IN/OUT, Absent";
        }
      }

      $totalWorkedHours += $reg_hrs;
        // $totalAbsencesHours += $absences;
      $totalTardinessHours += $tardiness;
      $totalUnderTimeHours += $undertime;
      $totalPaidHours += $LOG_leave;
      

    }



    foreach ($EMPLOYEES_SHIFTS as $EMPLOYEES_SHIFT) {

      $paid_leave = 0;
      $lwop1 = 0;
      $time_regular_start = $EMPLOYEES_SHIFT->time_regular_start;
      $time_regular_end   = $EMPLOYEES_SHIFT->time_regular_end;
      $time_regular_reg   = $EMPLOYEES_SHIFT->time_regular_reg;


      // foreach ($LEAVE_ASSIGNS as $LEAVE_ASSIGN) {
      //   if ($LEAVE_ASSIGN->leave_date == $EMPLOYEES_SHIFT->date) {
      //     $leave_type_name      = $this->home_model->GET_SPECIFIC_LEAVE_NAME($LEAVE_ASSIGN->type);
      //     if ($leave_type_name != "Leave Without Pay") {
      //       $paid_leave           = $LEAVE_ASSIGN->duration;
      //     } else {
      //       $lwop1                 = $LEAVE_ASSIGN->duration;
      //     }
      //   }
      // }

      // $attendance_result      = $this->home_model->GET_SPECIFIC_DATE_ATTENDANCE_LOG_IN_OUT($user_id, $EMPLOYEES_SHIFT->date);
      // if ($attendance_result) {

      //   $time_in            = $attendance_result->time_in;
      //   $time_out           = $attendance_result->time_out;

      //   $work_hours = $time_regular_reg;
      //   if ($time_in != "00:00" && $time_out != "00:00") {

      //     $in_min                 = $this->convert_time_to_float($time_in, 'minute') - $this->convert_time_to_float($time_regular_start, 'minute');
      //     $tardiness                 =  ceil($in_min / 30);
      //     if ($in_min < 0) {
      //       $in_min  = 0;
      //     }
      //     $out_min                = $this->convert_time_to_float($time_regular_end, 'minute') - $this->convert_time_to_float($time_out, 'minute');
      //     if ($out_min < 0) {
      //       $out_min  = 0;
      //     }
      //     $undertime  =  ceil($out_min / 30);
      //     $lwop = 0;
      //     $reg_hrs    = $work_hours - $lwop - $tardiness - $undertime;

      //     if ($reg_hrs < 0) {
      //       $reg_hrs = 0;
      //       $tardiness = 0;
      //       $undertime = 0;
      //       // $absences =  $work_hours;
      //     }
      //   }
      //   // $totalWorkedHours += $reg_hrs;
      //   // // $totalAbsencesHours += $absences;
      //   // $totalTardinessHours += $tardiness;
      //   // $totalUnderTimeHours += $undertime;
      // } else {
      //   $time_regular_reg   = $EMPLOYEES_SHIFT->time_regular_reg;
      //   $absences =  $time_regular_reg - $paid_leave - $lwop1;
      //   $totalAbsencesHours += $absences;
      // }
    }

    // }

    // if ($LEAVE_ASSIGNS) {
    //   foreach ($LEAVE_ASSIGNS as $LEAVE_ASSIGN) {
    //     $type_name      = $this->home_model->GET_SPECIFIC_LEAVE_NAME($LEAVE_ASSIGN->type);
    //     if ($type_name != "Leave Without Pay") {
    //       $totalPaidHours += $LEAVE_ASSIGN->duration;
    //     } else {
    //       $totalLeaveWithoutPay += $LEAVE_ASSIGN->duration;
    //     }
    //   }
    // }
    // $totalWorkedHours = 40;

    // $totalTardinessHours = 5;
    // $totalUnderTimeHours = 2.5;
    $totalHours = $totalWorkedHours + $totalPaidHours + $totalAbsencesHours + $totalTardinessHours + $totalUnderTimeHours;
    $data['TK_DATE_COVERAGE_HOURS']           =  50;
    $data['TK_DATE_COVERAGE_BAR']             =  50;

    $data['TK_WORKED_HOURS']                  =  $totalWorkedHours;
    $data['TK_WORKED_BAR']                    =  (($totalWorkedHours) ? $totalWorkedHours / $totalHours : 0) * 100;
    $data['TK_PAID_HOURS']                    =  $totalPaidHours;
    $data['TK_PAID_BAR']                      =  (($totalPaidHours) ? $totalPaidHours / $totalHours : 0) * 100;
    $data['TK_LEAVE_WITHOUT_PAY_HOURS']       =  $totalLeaveWithoutPay;
    $data['TK_LWOP_BAR']                      =  (($totalLeaveWithoutPay) ? $totalLeaveWithoutPay / $totalHours : 0) * 100;
    $data['TK_ABSENCES_HOURS']                =  $totalAbsencesHours;
    $data['TK_ABSENCES_BAR']                  =  (($totalAbsencesHours) ? $totalAbsencesHours / $totalHours : 0) * 100;
    $data['TK_TARDINESS_HOURS']               =  $totalTardinessHours;
    $data['TK_TARDINES_BAR']                  =  (($totalTardinessHours) ? $totalTardinessHours / $totalHours : 0) * 100;
    $data['TK_UNDER_TIME_HOURS']              =  $totalUnderTimeHours;
    $data['TK_UNDER_TIME_BAR']                =  (($totalUnderTimeHours) ? $totalUnderTimeHours / $totalHours : 0) * 100;

    // $data['ATTENDANCE_RECORDS']                     = $ATTENDANCE_RECORDS;
    // $data['LEAVE_ASSIGNS']                          = $LEAVE_ASSIGNS;
    // $data['EMPLOYEES_SHIFTS']                       = $EMPLOYEES_SHIFTS;

    
    $this->load->view('templates/header');
    $this->load->view('home/home_views', $data);
  }


  function deduction_in($time_in, $shift_in)
  {
    $shift_in_min           = $this->convert_time_to_float($shift_in, 'minute');
    $time_in_min            = $this->convert_time_to_float($time_in, 'minute');
    $in_min                 = $time_in_min - $shift_in_min;

    $shift_in_min;
    $time_in_min;
    $in_min;

    $in_ded                 = 0;
    if (($in_min > 0) && ($in_min <= 30)) {
      $in_ded = 0.5;
    } else if (($in_min > 30) && ($in_min <= 60)) {
      $in_ded = 1;
    } else if (($in_min > 60) && ($in_min <= 90)) {
      $in_ded = 1.5;
    } else if (($in_min > 90) && ($in_min <= 120)) {
      $in_ded = 2.0;
    } else if (($in_min > 120) && ($in_min <= 150)) {
      $in_ded = 2.5;
    } else if (($in_min > 150) && ($in_min <= 180)) {
      $in_ded = 3.0;
    } else if (($in_min > 180) && ($in_min <= 210)) {
      $in_ded = 3.5;
    } else if (($in_min > 210) && ($in_min <= 240)) {
      $in_ded = 4.5;
    } else if (($in_min > 240) && ($in_min <= 270)) {
      $in_ded = 5.0;
    } else if (($in_min > 270) && ($in_min <= 300)) {
      $in_ded = 5.5;
    } else if (($in_min > 300) && ($in_min <= 330)) {
      $in_ded = 6.0;
    } else if (($in_min > 330) && ($in_min <= 360)) {
      $in_ded = 6.5;
    } else if (($in_min > 360) && ($in_min <= 390)) {
      $in_ded = 7.0;
    } else if (($in_min > 390) && ($in_min <= 420)) {
      $in_ded = 7.5;
    } else if (($in_min > 420)) {
      $in_ded = 8.0;
    }
    return $in_ded;
  }


  function deduction_out($time_out, $shift_out)
  {
    $shift_out_min          =  $this->convert_time_to_float($shift_out, 'minute');
    $time_out_min           =  $this->convert_time_to_float($time_out, 'minute');

    $out_min                = $shift_out_min - $time_out_min;

    $out_min;
    $time_out_min;
    $shift_out_min;

    $out_ded                = 0;
    if (($out_min > 0) && ($out_min <= 30)) {
      $out_ded = 0.5;
    } else if (($out_min > 30) && ($out_min <= 60)) {
      $out_ded = 1.0;
    } else if (($out_min > 60) && ($out_min <= 90)) {
      $out_ded = 1.5;
    } else if (($out_min > 90) && ($out_min <= 120)) {
      $out_ded = 2.0;
    } else if (($out_min > 120) && ($out_min <= 150)) {
      $out_ded = 2.5;
    } else if (($out_min > 150) && ($out_min <= 180)) {
      $out_ded = 3.0;
    } else if (($out_min > 180) && ($out_min <= 210)) {
      $out_ded = 3.5;
    } else if (($out_min > 210) && ($out_min <= 240)) {
      $out_ded = 4.0;
    } else if (($out_min > 240) && ($out_min <= 270)) {
      $out_ded = 4.5;
    } else if (($out_min > 270) && ($out_min <= 300)) {
      $out_ded = 5.0;
    } else if (($out_min > 300) && ($out_min <= 330)) {
      $out_ded = 5.5;
    } else if (($out_min > 330) && ($out_min <= 360)) {
      $out_ded = 6.0;
    } else if (($out_min > 360) && ($out_min <= 390)) {
      $out_ded = 6.5;
    } else if (($out_min > 390) && ($out_min <= 420)) {
      $out_ded = 7.0;
    } else if (($out_min > 420) && ($out_min <= 450)) {
      $out_ded = 7.5;
    } else if (($out_min > 450)) {
      $out_ded = 8.0;
    }
    return $out_ded;
  }

  function convert_time_to_float($time, $type)
  {
    $split_time_in            = explode(":", $time);
    if ($type == 'minute') {
      $converted_time         = ((float)$split_time_in[0] * 60) + (float)$split_time_in[1];
    } else {
      $converted_time         = (float)$split_time_in[0] + ((float)$split_time_in[1] / 60);
    }
    return (float)$converted_time;
  }
  function home_2()
  {
    $user_id = $this->session->userdata('SESS_USER_ID');

    $data["ANNOUNCEMENT_STATUS"]                    = $this->home_model->GET_HOME_ANNOUNCEMENT();
    $data["CELEB_STATUS"]                           = $this->home_model->GET_HOME_CELEBRATION();
    $data["DATE_STATUS"]                            = $this->home_model->GET_HOME_DATE();
    $data["LEAVE_STATUS"]                           = $this->home_model->GET_HOME_LEAVE();
    $data["WHOS_OUT_STATUS"]                        = $this->home_model->GET_HOME_WHOS_OUT();
    $data["START_GUIDE_STATUS"]                     = $this->home_model->GET_HOME_START_GUIDE();
    $data["NEW_MEMBER_STATUS"]                      = $this->home_model->GET_HOME_NEW_MEMBER();

    $data['isholiday']                              = $this->home_model->MOD_DISP_HOLIDAY_BASED_DATE(date('Y-m-d'));
    $data['DISP_USER_INFO']                         = $this->home_model->MOD_DISP_HOME($user_id);
    $data['DISP_ANNOUNCEMENTS_INFO']                = $this->home_model->MOD_DISP_ANNOUNCEMENTS(2);
    $data['DISP_EMPOLYEE_INFO']                     = $this->home_model->MOD_DISP_ALL_EMPLOYEES_BY_DATE();

    $data['DISP_ON_LEAVE']                          = $this->home_model->MOD_DISP_ON_LEAVE();
    $data['desktop_logo']                           = $this->home_model->GET_DESKTOP_LOGO()['value'];
    $data['mobile_logo']                            = $this->home_model->GET_MOBILE_LOGO()['value'];
    $data['DISP_NEW_EMP']                           = $this->home_model->DISP_NEW_EMP_MONTH();
    $data['C_POSITIONS']                            = $this->home_model->GET_POSITION();

    $leave_app_val = $data['LEAVE_APPROVED_COUNT']  = $this->home_model->LEAVE_APPROVED_COUNT($user_id);
    $leave_rej_val = $data['LEAVE_REJECTED_COUNT']  = $this->home_model->LEAVE_REJECTED_COUNT($user_id);
    $data['LEAVE_REJECTED_COUNT2']                  = $this->home_model->LEAVE_REJECTED_COUNT($user_id);
    $data['LEAVE_PENDING_COUNT']                    = $this->home_model->LEAVE_ALL_COUNT($user_id);

    $data['HOLIDAYWORK_APPROVED_COUNT']             = $this->home_model->HOLIDAYWORK_APPROVED_COUNT($user_id);
    $data['HOLIDAYWORK_REJECTED_COUNT']             = $this->home_model->HOLIDAYWORK_REJECTED_COUNT($user_id);
    $data['HOLIDAYWORK_PENDING_COUNT']              = $this->home_model->HOLIDAYWORK_ALL_COUNT($user_id);

    $ot_app_val = $data['OVERTIME_APPROVED_COUNT']  = $this->home_model->OVERTIME_APPROVED_COUNT($user_id);
    $ot_rej_val = $data['OVERTIME_REJECTED_COUNT']  = $this->home_model->OVERTIME_REJECTED_COUNT($user_id);
    $data['OVERTIME_PENDING_COUNT']                 = $this->home_model->OVERTIME_ALL_COUNT($user_id);

    $time_app_val = $data['TIME_APPROVED_COUNT']    = $this->home_model->TIME_APPROVED_COUNT($user_id);
    $time_rej_val = $data['TIME_REJECTED_COUNT']    = $this->home_model->TIME_REJECTED_COUNT($user_id);
    $data['TIME_PENDING_COUNT']                     = $this->home_model->TIME_ALL_COUNT($user_id);


    $data['HOLIDAYWORK_APPROVALS']                  = $this->home_model->GET_HOLIDAYWORK_APPROVALS($user_id);
    $data['LEAVE_APPROVALS']                        = $this->home_model->GET_LEAVE_FOR_APPROVALS($user_id);
    $data['OVERTIME_APPROVALS']                     = $this->home_model->GET_OVERTIME_APPROVALS($user_id);
    $data['TIME_ADJUSTMENT']                        = $this->home_model->GET_TIME_ADJUSTMENT_APPROVALS($user_id);
    $data['LEAVES']                                 = $this->home_model->GET_LEAVES($user_id);
    $data['HOLIDAYWORKS']                           = $this->home_model->GET_HOLIDAYWORK($user_id);
    $data['OVERTIMES']                              = $this->home_model->GET_OVERTIME($user_id);
    $data['TIME_ADJUSTMENTS']                       = $this->home_model->GET_TIME_ADJUSTMENTS($user_id);
    // echo '<pre>';
    // var_dump( $data['DISP_ANNOUNCEMENTS_INFO']);
    // return;
    $this->load->view('templates/header');
    $this->load->view('home/home_views_2', $data);
  }
  // function approve_leave($id){
  //     $response=$this->home_model->update_leaveStatus($id,'Approved');
  //     redirect('/home');
  // }
  // function reject_leave($id){
  //     $response=$this->home_model->update_leaveStatus($id,'Rejected');
  //     redirect('/home');
  // }
  // function approve_overtime($id){
  //     $response=$this->home_model->update_overtimeStatus($id,'Approved');
  //     redirect('/home');
  // }
  // function reject_overtime($id){
  //     $response=$this->home_model->update_overtimeStatus($id,'Rejected');
  //     redirect('/home');
  // }
  // function approve_time_adjustment($id){
  //     $response=$this->home_model->update_timeAdjustmentStatus($id,'Approved');
  //     redirect('/home');
  // }
  // function reject_time_adjustment($id){
  //     $response=$this->home_model->update_timeAdjustmentStatus($id,'Rejected');
  //     redirect('/home');
  // }

  function download_file($id)
  {
    $this->load->helper('download');
    $filepath                                   = $this->home_model->GET_FILE_PATH($id);
    $path                                       = file_get_contents(base_url() . "assets_user/files/hressentials/" . $filepath);
    $file                                       = 'Eyebox/' . $filepath;
    force_download($file, $path);
  }


  function update_leave_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $leave_assign       = $this->home_model->GET_LEAVE_ASSIGN($id);
    $approvers          = $this->home_model->GET_USER_APPROVERS($leave_assign->empl_id, 'tbl_leave_approvers');
    $date_created       = date('Y-m-d H:i:s');
    $emp_id             = $this->session->userdata('SESS_USER_ID');

    if ($leave_assign->status == 'Pending 1') {
      $status = 'Pending 2';
      $this->home_model->UPDATE_LEAVE_ASSIGN($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_1;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $leave_assign->empl_id, 'type' => 'leave',
        'content_id' => $id, 'location' => 'selfservices/my_leaves', 'description' => $description
      );

      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_2a;
      $notif_data['description']  = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/leave_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }
    if ($leave_assign->status == 'Pending 2') {
      $status = 'Pending 3';
      $this->home_model->UPDATE_LEAVE_ASSIGN2($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_2;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $leave_assign->empl_id, 'type' => 'leave',
        'content_id' => $id, 'location' => 'selfservices/my_leaves', 'description' => $description
      );

      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_3a;
      $notif_data['description']  = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/leave_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }
    if ($leave_assign->status == 'Pending 3') {
      $status = 'Approved';
      $this->home_model->UPDATE_LEAVE_ASSIGN3($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been fully approved by " . $approvers->approver_3;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $leave_assign->empl_id, 'type' => 'leave',
        'content_id' => $id, 'location' => 'selfservices/my_leaves', 'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }
    $this->session->set_userdata('succ_approved', 'Leave request has been approved!');
    redirect('/home');
  }

  function reject_leave_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $leave_assign       = $this->home_model->GET_LEAVE_ASSIGN($id);
    $approvers          = $this->home_model->GET_USER_APPROVERS($leave_assign->empl_id, 'tbl_leave_approvers');
    $status             = 'Rejected';
    $date_created       = date('Y-m-d H:i:s');
    $emp_id             = $this->session->userdata('SESS_USER_ID');
    $approver_name      = "";
    if ($leave_assign->status == 'Pending 1') {
      $this->home_model->UPDATE_LEAVE_ASSIGN($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_1;
    } elseif ($leave_assign->status == 'Pending 2') {
      $this->home_model->UPDATE_LEAVE_ASSIGN2($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_2;
    } elseif ($leave_assign->status == 'Pending 3') {
      $this->home_model->UPDATE_LEAVE_ASSIGN3($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_3;
    }
    $description = "Leave Application Review for [LEA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been rejected by " . $approver_name;
    $notif_data = array(
      'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $leave_assign->empl_id, 'type' => 'leave',
      'content_id' => $id, 'location' => 'selfservices/my_leaves', 'description' => $description
    );
    $this->home_model->ADD_NOTIFICATION($notif_data);
    $this->session->set_userdata('succ_approved', 'Leave request has been rejected!');
    redirect('/home');
  }




  function update_holidaywork_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }

    $emp_id                                   = $this->session->userdata('SESS_USER_ID');
    $holiday_work                             = $this->home_model->GET_HOLIDAYWORK_ASSIGN($id);
    $approvers                                = $this->home_model->GET_USER_APPROVERS($holiday_work->empl_id, 'tbl_overtime_approvers');

    if ($holiday_work->status == 'Pending 1') {
      $status = 'Pending 2';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN($status, $emp_id, $date_created, $id);
      $description = "Holiday Work Application Review for [HWA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_1;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $holiday_work->empl_id, 'type' => 'holiday work',
        'content_id' => $id, 'location' => 'selfservices/my_holiday_work',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_2a;
      $notif_data['description']  = "Holiday Work Application Review for [HWA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/holidaywork_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    if ($holiday_work->status == 'Pending 2') {
      $status = 'Pending 3';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN2($status, $emp_id, $date_created, $id);
      $description = "Holiday Work Application Review for [HWA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_2;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $holiday_work->empl_id, 'type' => 'holiday work',
        'content_id' => $id, 'location' => 'selfservices/my_holiday_work',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_3a;
      $notif_data['description']  = "Holiday Work Application Review for [HWA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/holidaywork_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    if ($holiday_work->status == 'Pending 3') {
      $status                               = 'Approved';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN3($status, $emp_id, $date_created, $id);
      $description = "Holiday Work Application Review for [HWA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been fully approved by " . $approvers->approver_3;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $holiday_work->empl_id, 'type' => 'holiday work',
        'content_id' => $id, 'location' => 'selfservices/my_holiday_work',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    $this->session->set_userdata('succ_approved', 'Holiday work request has been approved!');
    redirect('home');
  }


  function reject_holidaywork_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $holiday_work                          = $this->home_model->GET_HOLIDAYWORK_ASSIGN($id);
    $approvers                          = $this->home_model->GET_USER_APPROVERS($holiday_work->empl_id, 'tbl_overtime_approvers');
    $approver_name                                 = "";
    if ($holiday_work->status == 'Pending 1') {
      $status                               = 'Rejected';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_1;
    }

    if ($holiday_work->status == 'Pending 2') {
      $status                               = 'Rejected';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN2($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_2;
    }

    if ($holiday_work->status == 'Pending 3') {
      $status                               = 'Rejected';
      $date_created                         = date('Y-m-d H:i:s');
      $emp_id                               = $this->session->userdata('SESS_USER_ID');
      $this->home_model->UPDATE_HOLIDAYWORK_ASSIGN3($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_3;
    }
    // echo '<pre>';
    // var_dump($approver_name);
    // return;
    $description = "Holiday Work Application Review for [MHW" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been rejected by " . $approver_name;
    $notif_data = array(
      'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $holiday_work->empl_id, 'type' => 'holiday work',
      'content_id' => $id, 'location' => 'selfservices/my_holiday_work', 'description' => $description
    );
    $this->home_model->ADD_NOTIFICATION($notif_data);
    $this->session->set_userdata('succ_approved', 'Holiday work request has been rejected!');
    redirect('home');
  }


  function update_overtime_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $overtime_assign                            = $this->home_model->GET_OVERTIME_ASSIGN($id);
    $approvers                                  = $this->home_model->GET_USER_APPROVERS($overtime_assign->empl_id, 'tbl_overtime_approvers');

    $date_created                           = date('Y-m-d H:i:s');
    $emp_id                                 = $this->session->userdata('SESS_USER_ID');

    if ($overtime_assign->status == 'Pending 1') {
      $status = 'Pending 2';
      $this->home_model->UPDATE_OVERTIME_ASSIGN($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [OVT" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_1;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $overtime_assign->empl_id, 'type' => 'overtime',
        'content_id' => $id, 'location' => 'selfservices/my_overtimes',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_2a;
      $notif_data['description']  = "Overtime Application Review for [OVA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/overtime_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    if ($overtime_assign->status == 'Pending 2') {
      $status = 'Pending 3';
      $this->home_model->UPDATE_OVERTIME_ASSIGN2($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [OVT" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_2;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $overtime_assign->empl_id, 'type' => 'overtime',
        'content_id' => $id, 'location' => 'selfservices/my_overtimes',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_3a;
      $notif_data['description']  = "Overtime Application Review for [OVA" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/overtime_approval";
      $this->selfservices_model->ADD_NOTIFICATION($notif_data);
    }

    if ($overtime_assign->status == 'Pending 3') {
      $status = 'Approved';
      $this->home_model->UPDATE_OVERTIME_ASSIGN3($status, $emp_id, $date_created, $id);
      $description = "Leave Application Review for [OVT" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been fully approved by " . $approvers->approver_3;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $overtime_assign->empl_id, 'type' => 'overtime',
        'content_id' => $id, 'location' => 'selfservices/my_overtimes',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }
    $this->session->set_userdata('succ_approved', 'Overtime request has been approved!');
    redirect('home');
  }


  function reject_overtime_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $overtime_assign                    = $this->home_model->GET_OVERTIME_ASSIGN($id);
    $date_created                       = date('Y-m-d H:i:s');
    $emp_id                             = $this->session->userdata('SESS_USER_ID');
    $status                             = 'Rejected';
    $approvers                          = $this->home_model->GET_USER_APPROVERS($overtime_assign->empl_id, 'tbl_overtime_approvers');
    $approver_name                      = "";
    if ($overtime_assign->status == 'Pending 1') {
      $this->home_model->UPDATE_OVERTIME_ASSIGN($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_1;
    }

    if ($overtime_assign->status == 'Pending 2') {
      $this->home_model->UPDATE_OVERTIME_ASSIGN2($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_2;
    }

    if ($overtime_assign->status == 'Pending 3') {
      $this->home_model->UPDATE_OVERTIME_ASSIGN3($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_3;
    }
    $description = "Overtime Application Review for [OVT" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been rejected by " . $approver_name;
    $notif_data = array(
      'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $overtime_assign->empl_id, 'type' => 'holiday work',
      'content_id' => $id, 'location' => 'selfservices/my_holiday_work', 'description' => $description
    );
    $this->home_model->ADD_NOTIFICATION($notif_data);
    $this->session->set_userdata('succ_approved', 'Overtime request has been rejected!');
    redirect('/home');
  }


  function approve_time_adj_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $time_adjustment_assign             = $this->home_model->GET_TIME_ADJUSTMENT_ASSIGN($id);
    $approvers                          = $this->home_model->GET_USER_APPROVERS($time_adjustment_assign->empl_id, 'tbl_overtime_approvers');
    $date_created = date('Y-m-d H:i:s');
    $emp_id = $this->session->userdata('SESS_USER_ID');

    if ($time_adjustment_assign->status == 'Pending 1') {
      $status = 'Pending 2';
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN($status, $emp_id, $date_created, $id);
      $description = "Time Ajustment Application Review for [ADJ" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_1;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $time_adjustment_assign->empl_id, 'type' => 'time adjustment',
        'content_id' => $id, 'location' => 'selfservices/my_time_adjustments',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_2a;
      $notif_data['description']  = "Time Adjustment Application Review for [TAD" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/time_adjustment_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    if ($time_adjustment_assign->status == 'Pending 2') {
      $status = 'Pending 3';
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN2($status, $emp_id, $date_created, $id);
      $description = "Time Ajustment Application Review for [ADJ" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been partially approved by " . $approvers->approver_2;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $time_adjustment_assign->empl_id, 'type' => 'time adjustment',
        'content_id' => $id, 'location' => 'selfservices/my_time_adjustments',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $notif_data['empl_id']      = $approvers->approver_3a;
      $notif_data['description']  = "Time Adjustment Application Review for [TAD" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] by " . $approvers->employee . " has been requested";
      $notif_data['location']     = "selfservices/time_adjustment_approval";
      $this->home_model->ADD_NOTIFICATION($notif_data);
    }

    if ($time_adjustment_assign->status == 'Pending 3') {
      $status = 'Approved';
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN3($status, $emp_id, $date_created, $id);
      $description = "Time Ajustment Application Review for [ADJ" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been fully approved by " . $approvers->approver_3;
      $notif_data = array(
        'create_date' => date('Y-m-d H:i:s'),
        'empl_id' => $time_adjustment_assign->empl_id, 'type' => 'time adjustment',
        'content_id' => $id, 'location' => 'selfservices/my_time_adjustments',
        'description' => $description
      );
      $this->home_model->ADD_NOTIFICATION($notif_data);
      $this->insert_approved_time_adjustment($id);
    }
    $this->session->set_userdata('succ_approved', 'Time Adjustment request has been approved!');
    redirect('home');
  }


  function reject_time_adj_assign()
  {
    $id                 = $this->input->post('id');
    if (!$id) {
      redirect('home');
    }
    $time_adjustment_assign             = $this->home_model->GET_TIME_ADJUSTMENT_ASSIGN($id);
    $approvers                          = $this->home_model->GET_USER_APPROVERS($time_adjustment_assign->empl_id, 'tbl_overtime_approvers');
    $approver_name                      = "";
    $status = 'Rejected';
    $date_created = date('Y-m-d H:i:s');
    $emp_id = $this->session->userdata('SESS_USER_ID');

    if ($time_adjustment_assign->status == 'Pending 1') {
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_1;
    }

    if ($time_adjustment_assign->status == 'Pending 2') {
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN2($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_2;
    }

    if ($time_adjustment_assign->status == 'Pending 3') {
      $this->home_model->UPDATE_TIME_ADJ_ASSIGN3($status, $emp_id, $date_created, $id);
      $approver_name = $approvers->approver_3;
    }
    $description = "Time Adjustment Application Review for [ADJ" . str_pad($id, 5, '0', STR_PAD_LEFT) . "] has been rejected by " . $approver_name;
    $notif_data = array(
      'create_date' => date('Y-m-d H:i:s'), 'empl_id' => $time_adjustment_assign->empl_id, 'type' => 'time adjustment',
      'content_id' => $id, 'location' => 'selfservices/my_time_adjustments', 'description' => $description
    );
    $this->home_model->ADD_NOTIFICATION($notif_data);
    $this->session->set_userdata('succ_approved', 'Time Adjustment request has been rejected!');
    redirect('/home');
  }


  function insert_approved_time_adjustment($id)
  {

    $time_adj                                   = $this->home_model->GET_APPROVED_TIME_ADJUSTMENT($id);
    $attendance_shift                           = $this->home_model->GET_ATTENDANCE_SHIFT($time_adj->shift_type);

    $shift_id                                   = $attendance_shift->id;

    $date                                       = $time_adj->date_adjustment;
    $empl_id                                    = $time_adj->empl_id;
    $timeIn1                                    = $time_adj->time_in_1;
    $timeOut1                                   = $time_adj->time_out_1;
    $timeIn2                                    = $time_adj->time_in_2;
    $timeOut2                                   = $time_adj->time_out_2;

    $result                                     = $this->home_model->IS_DUPLICATE_TIME_ADDJ($empl_id, $date);
    $att_shift_result                           = $this->home_model->IS_DUPLICATE_ATTENDANCE_SHIFTASSIGN($empl_id, $date);

    if ($result <= 0) {
      $this->home_model->INSERT_TIME_ADJUSTMENT($timeIn1, $timeOut1, $timeIn2, $timeOut2, $empl_id, $date);
    } else {
      $this->home_model->UPDATE_TIME_ADJUSTMENT($timeIn1, $timeOut1, $timeIn2, $timeOut2, $empl_id, $date);
    }

    if ($att_shift_result <= 0) {
      $this->home_model->INSERT_ATTENDANCE_SHIFT_ASSIGN($shift_id, $empl_id, $date);
    } else {
      $this->home_model->UPDATE_ATTENDANCE_SHIFT_ASSIGN($shift_id, $empl_id, $date);
    }

    return;
  }
}
